1. Create a react app and copy the public and src folders into your react app folder.

2. Run command 'npm start'

3. All the properties are listed in properties.json file under public folder.

4. Note: The images for properties are under Assets folder under public folder. The css files are stored in css folder under public folder.

5. The Home Component is under Pages folder in src folder.